﻿/*
 * UART_Cfg.h
 *
 * Created: 25/07/2020 08:23:39 ص
 *  Author: Ali
 */ 


#ifndef UART_CFG_H_
#define UART_CFG_H_

#define BOUD_RATE   9600



#endif /* UART_CFG_H_ */