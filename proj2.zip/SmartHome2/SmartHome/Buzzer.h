/*
 * Buzzer.h
 *
 * Created: 7/14/2020 12:51:12 AM
 *  Author: SAT
 */ 


#ifndef BUZZER_H
#define BUZZER_H 

#include "DIO.h"

void Buzzer_init(void);

void Buzzer_on(void);

void Buzzer_off(void);






#endif /* BUZZER_H_ */